package cz.mallat.uasparser;

public class Utils {

	public static boolean validString(String s) {
		return s != null && !s.trim().isEmpty();
	}

}
