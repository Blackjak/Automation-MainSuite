package org.browsermob.proxy.http;

public class BadURIException extends RuntimeException {
    public BadURIException(String message) {
        super(message);
    }
}
