NOTICE: this project has been forked and is being maintained at https://github.com/lightbody/browsermob-proxy
